package com.patterns.decorator2.swiggey.DeliveryService;

public interface DeliveryService {

    void delivery(String orderId);
}
