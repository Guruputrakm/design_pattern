package com.patterns.decorator2.uber;

public interface RideBookService {
    void bookRide(Request req);
}
