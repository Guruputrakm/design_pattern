package com.patterns.decorator2.uber;

public record Request(String user, String from, String to, String requestedId) {
}
