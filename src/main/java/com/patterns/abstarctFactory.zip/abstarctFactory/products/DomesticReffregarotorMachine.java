package com.patterns.abstarctFactory.products;

public class DomesticReffregarotorMachine extends Refregerator{
    @Override
    public void applienceFunction() {
        System.out.println("using for running the Domestic  machine the name is "+super.getName());
    }
}
