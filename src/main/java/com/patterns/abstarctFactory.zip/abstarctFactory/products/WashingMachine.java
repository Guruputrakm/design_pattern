package com.patterns.abstarctFactory.products;

public abstract class WashingMachine implements Applience{

    public String getName() {
        return "This is washing machine of type ";
    }
}
