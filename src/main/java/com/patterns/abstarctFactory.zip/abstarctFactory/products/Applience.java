package com.patterns.abstarctFactory.products;

public interface Applience {

    void applienceFunction();
}
