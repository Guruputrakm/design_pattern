package com.patterns.abstarctFactory.products;

public abstract class Refregerator implements Applience{

    public String getName() {
        return "This is Reffregartor  machine of type ";
    }
}
