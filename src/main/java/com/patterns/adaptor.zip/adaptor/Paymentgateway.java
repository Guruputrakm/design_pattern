package com.patterns.adaptor;

public interface Paymentgateway {
    boolean processPayment(int amount);
}
