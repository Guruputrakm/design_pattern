package com.patterns.adaptor;

public class PhonePePay {

    public boolean payWithPhonePe(int amount) {

        System.out.println("The amount "+amount+" is paid through the phonepe ");
        return true;
    }

}
