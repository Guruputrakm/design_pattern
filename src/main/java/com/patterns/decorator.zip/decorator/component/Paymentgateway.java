package com.patterns.decorator.component;

public interface Paymentgateway {

    boolean processPayment(int amount);
}
