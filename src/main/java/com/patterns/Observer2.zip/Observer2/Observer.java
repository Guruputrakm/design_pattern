package com.patterns.Observer2;

public interface Observer {

    void onEvent(int temp);
}
